# Development scenario quality summary

**SYNTHETIC - NOT CALIBRATED TO A REAL TERMINAL**

Row status counts: {'rejected': 1, 'accepted': 14, 'blocked': 5}
BAP projection / DynamicBAPEnv reset success: 14 of 14
Unique physical fingerprints: 14

| Family | Scenarios | Vessels | Containers (mean) | TEU (mean) | Moves (mean) | Import / export / transshipment share | 40 ft share | Initial occupancy (mean) | TEU pressure ratio (mean) |
| --- | ---: | --- | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| itp_heavy | 4 | 24-24 | 12519 | 20074 | 13904 | 0.442 / 0.391 / 0.167 | 0.603 | 0.744 | 2.28 |
| itp_low | 5 | 8-8 | 5468 | 8776 | 4668 | 0.569 / 0.302 / 0.129 | 0.605 | 0.500 | 1.00 |
| itp_medium | 5 | 16-16 | 8660 | 13864 | 9270 | 0.468 / 0.373 / 0.160 | 0.601 | 0.505 | 1.58 |
