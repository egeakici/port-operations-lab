# Development scenario quality summary

**SYNTHETIC - NOT CALIBRATED TO A REAL TERMINAL**

Row status counts: {'accepted': 80}
BAP projection / DynamicBAPEnv reset success: 80 of 80
Unique physical fingerprints: 80

| Family | Scenarios | Vessels | Containers (mean) | TEU (mean) | Moves (mean) | Import / export / transshipment share | 40 ft share | Initial occupancy (mean) | TEU pressure ratio (mean) |
| --- | ---: | --- | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| itp_heavy | 30 | 24-24 | 16993 | 27182 | 13879 | 0.595 / 0.284 / 0.122 | 0.600 | 0.500 | 1.03 |
| itp_low | 10 | 8-8 | 11009 | 17624 | 4694 | 0.786 / 0.150 / 0.064 | 0.601 | 0.500 | 0.67 |
| itp_medium | 30 | 16-16 | 14159 | 22648 | 9263 | 0.673 / 0.229 / 0.098 | 0.600 | 0.500 | 0.86 |
| itp_yard_bottleneck | 10 | 18-18 | 18468 | 29561 | 10785 | 0.710 / 0.203 / 0.087 | 0.601 | 0.700 | 1.12 |

Initial inventory (mandatory = contract-implied pre-staged exports and pre-episode transshipment; optional = background imports up to the target):

| Family | Capacity TEU | Mandatory TEU (min-max) | Mandatory fraction (max) | Optional TEU (mean) | Target status | Exogenous occupancy proxy peak (max) | Block ship-side / vessel demand |
| --- | ---: | --- | ---: | ---: | --- | ---: | ---: |
| itp_heavy | [26400.0] | 3356-9686 | 0.367 | 7128 | {'MET': 30} | 0.545 | 0.87 |
| itp_low | [26400.0] | 1821-2914 | 0.110 | 10688 | {'MET': 10} | 0.523 | 0.87 |
| itp_medium | [26400.0] | 1732-6037 | 0.229 | 9256 | {'MET': 30} | 0.529 | 0.87 |
| itp_yard_bottleneck | [26400.0] | 3010-5980 | 0.227 | 13957 | {'MET': 10} | 0.730 | 0.43 |

Rejection reasons: {}

Runtime occupancy, congestion, blocking and turnaround do not exist before the Step 4 simulator; nothing here is a simulated outcome.
